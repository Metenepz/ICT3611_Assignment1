﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRunningClub
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tbEventMan = New System.Windows.Forms.TabPage()
        Me.btnDelEvent = New System.Windows.Forms.Button()
        Me.btnUpdateEvent = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtEventDate = New System.Windows.Forms.DateTimePicker()
        Me.txtDistance = New System.Windows.Forms.TextBox()
        Me.txtRegFee = New System.Windows.Forms.TextBox()
        Me.txtLocation = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.lstEvents = New System.Windows.Forms.ListBox()
        Me.tbMemMan = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnDelMemb = New System.Windows.Forms.Button()
        Me.btnUpdateMemb = New System.Windows.Forms.Button()
        Me.btnSaveMemb = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbCompeted = New System.Windows.Forms.ComboBox()
        Me.txtFinishTime = New System.Windows.Forms.TextBox()
        Me.txtOwing = New System.Windows.Forms.TextBox()
        Me.dtDJoined = New System.Windows.Forms.DateTimePicker()
        Me.cmbGender = New System.Windows.Forms.ComboBox()
        Me.dtDOB = New System.Windows.Forms.DateTimePicker()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtMemberNum = New System.Windows.Forms.TextBox()
        Me.lstMembers = New System.Windows.Forms.ListBox()
        Me.tbRaceMan = New System.Windows.Forms.TabPage()
        Me.lstAthletes = New System.Windows.Forms.ListBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnSaveAthlete = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtTimeCompleted = New System.Windows.Forms.TextBox()
        Me.cmbAthlets = New System.Windows.Forms.ComboBox()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.cmbRaces = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.tbEventMan.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tbMemMan.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.tbRaceMan.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tbEventMan)
        Me.TabControl1.Controls.Add(Me.tbMemMan)
        Me.TabControl1.Controls.Add(Me.tbRaceMan)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(774, 349)
        Me.TabControl1.TabIndex = 0
        '
        'tbEventMan
        '
        Me.tbEventMan.Controls.Add(Me.btnDelEvent)
        Me.tbEventMan.Controls.Add(Me.btnUpdateEvent)
        Me.tbEventMan.Controls.Add(Me.GroupBox1)
        Me.tbEventMan.Controls.Add(Me.lstEvents)
        Me.tbEventMan.Location = New System.Drawing.Point(4, 22)
        Me.tbEventMan.Name = "tbEventMan"
        Me.tbEventMan.Padding = New System.Windows.Forms.Padding(3)
        Me.tbEventMan.Size = New System.Drawing.Size(766, 323)
        Me.tbEventMan.TabIndex = 2
        Me.tbEventMan.Text = "Even Management"
        Me.tbEventMan.UseVisualStyleBackColor = True
        '
        'btnDelEvent
        '
        Me.btnDelEvent.Location = New System.Drawing.Point(650, 267)
        Me.btnDelEvent.Name = "btnDelEvent"
        Me.btnDelEvent.Size = New System.Drawing.Size(104, 42)
        Me.btnDelEvent.TabIndex = 3
        Me.btnDelEvent.Text = "Delete Event"
        Me.btnDelEvent.UseVisualStyleBackColor = True
        '
        'btnUpdateEvent
        '
        Me.btnUpdateEvent.Location = New System.Drawing.Point(441, 267)
        Me.btnUpdateEvent.Name = "btnUpdateEvent"
        Me.btnUpdateEvent.Size = New System.Drawing.Size(113, 42)
        Me.btnUpdateEvent.TabIndex = 2
        Me.btnUpdateEvent.Text = "Update Event"
        Me.btnUpdateEvent.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtEventDate)
        Me.GroupBox1.Controls.Add(Me.txtDistance)
        Me.GroupBox1.Controls.Add(Me.txtRegFee)
        Me.GroupBox1.Controls.Add(Me.txtLocation)
        Me.GroupBox1.Controls.Add(Me.txtTitle)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.btnClear)
        Me.GroupBox1.Controls.Add(Me.btnSave)
        Me.GroupBox1.Location = New System.Drawing.Point(434, 19)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(326, 214)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Provide the following Event info:"
        '
        'dtEventDate
        '
        Me.dtEventDate.Location = New System.Drawing.Point(137, 52)
        Me.dtEventDate.Name = "dtEventDate"
        Me.dtEventDate.Size = New System.Drawing.Size(183, 20)
        Me.dtEventDate.TabIndex = 11
        '
        'txtDistance
        '
        Me.txtDistance.Location = New System.Drawing.Point(137, 140)
        Me.txtDistance.Name = "txtDistance"
        Me.txtDistance.Size = New System.Drawing.Size(183, 20)
        Me.txtDistance.TabIndex = 10
        '
        'txtRegFee
        '
        Me.txtRegFee.Location = New System.Drawing.Point(137, 84)
        Me.txtRegFee.Name = "txtRegFee"
        Me.txtRegFee.Size = New System.Drawing.Size(183, 20)
        Me.txtRegFee.TabIndex = 9
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(137, 113)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(183, 20)
        Me.txtLocation.TabIndex = 8
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(137, 26)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(183, 20)
        Me.txtTitle.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 143)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Distance:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 116)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Location:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Registration Fee:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Date of Event:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Title:"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(231, 178)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(89, 30)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(7, 178)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(84, 30)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'lstEvents
        '
        Me.lstEvents.FormattingEnabled = True
        Me.lstEvents.Location = New System.Drawing.Point(6, 19)
        Me.lstEvents.Name = "lstEvents"
        Me.lstEvents.Size = New System.Drawing.Size(421, 290)
        Me.lstEvents.TabIndex = 0
        '
        'tbMemMan
        '
        Me.tbMemMan.Controls.Add(Me.GroupBox2)
        Me.tbMemMan.Controls.Add(Me.Label6)
        Me.tbMemMan.Controls.Add(Me.btnSearch)
        Me.tbMemMan.Controls.Add(Me.txtMemberNum)
        Me.tbMemMan.Controls.Add(Me.lstMembers)
        Me.tbMemMan.Location = New System.Drawing.Point(4, 22)
        Me.tbMemMan.Name = "tbMemMan"
        Me.tbMemMan.Padding = New System.Windows.Forms.Padding(3)
        Me.tbMemMan.Size = New System.Drawing.Size(766, 323)
        Me.tbMemMan.TabIndex = 0
        Me.tbMemMan.Text = "Member Management"
        Me.tbMemMan.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnDelMemb)
        Me.GroupBox2.Controls.Add(Me.btnUpdateMemb)
        Me.GroupBox2.Controls.Add(Me.btnSaveMemb)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.cmbCompeted)
        Me.GroupBox2.Controls.Add(Me.txtFinishTime)
        Me.GroupBox2.Controls.Add(Me.txtOwing)
        Me.GroupBox2.Controls.Add(Me.dtDJoined)
        Me.GroupBox2.Controls.Add(Me.cmbGender)
        Me.GroupBox2.Controls.Add(Me.dtDOB)
        Me.GroupBox2.Controls.Add(Me.txtSurname)
        Me.GroupBox2.Controls.Add(Me.txtName)
        Me.GroupBox2.Location = New System.Drawing.Point(418, 38)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(342, 279)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Provide the following member info:"
        '
        'btnDelMemb
        '
        Me.btnDelMemb.Location = New System.Drawing.Point(245, 115)
        Me.btnDelMemb.Name = "btnDelMemb"
        Me.btnDelMemb.Size = New System.Drawing.Size(91, 31)
        Me.btnDelMemb.TabIndex = 19
        Me.btnDelMemb.Text = "Delete Member"
        Me.btnDelMemb.UseVisualStyleBackColor = True
        '
        'btnUpdateMemb
        '
        Me.btnUpdateMemb.Location = New System.Drawing.Point(245, 57)
        Me.btnUpdateMemb.Name = "btnUpdateMemb"
        Me.btnUpdateMemb.Size = New System.Drawing.Size(91, 35)
        Me.btnUpdateMemb.TabIndex = 18
        Me.btnUpdateMemb.Text = "Update Member"
        Me.btnUpdateMemb.UseVisualStyleBackColor = True
        '
        'btnSaveMemb
        '
        Me.btnSaveMemb.Location = New System.Drawing.Point(245, 11)
        Me.btnSaveMemb.Name = "btnSaveMemb"
        Me.btnSaveMemb.Size = New System.Drawing.Size(91, 35)
        Me.btnSaveMemb.TabIndex = 17
        Me.btnSaveMemb.Text = "Save Member"
        Me.btnSaveMemb.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(242, 222)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(63, 13)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Finish Time:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 240)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(99, 13)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Race Competed In:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 203)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(79, 13)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "Amount Owing:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 171)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(67, 13)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Date Joined:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 133)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(45, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Gender:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 99)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 13)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Date of Birth:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 57)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Surname:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Name:"
        '
        'cmbCompeted
        '
        Me.cmbCompeted.FormattingEnabled = True
        Me.cmbCompeted.Location = New System.Drawing.Point(105, 237)
        Me.cmbCompeted.Name = "cmbCompeted"
        Me.cmbCompeted.Size = New System.Drawing.Size(121, 21)
        Me.cmbCompeted.TabIndex = 7
        '
        'txtFinishTime
        '
        Me.txtFinishTime.Location = New System.Drawing.Point(245, 238)
        Me.txtFinishTime.Name = "txtFinishTime"
        Me.txtFinishTime.Size = New System.Drawing.Size(91, 20)
        Me.txtFinishTime.TabIndex = 6
        '
        'txtOwing
        '
        Me.txtOwing.Location = New System.Drawing.Point(105, 200)
        Me.txtOwing.Name = "txtOwing"
        Me.txtOwing.Size = New System.Drawing.Size(121, 20)
        Me.txtOwing.TabIndex = 5
        '
        'dtDJoined
        '
        Me.dtDJoined.Location = New System.Drawing.Point(105, 165)
        Me.dtDJoined.Name = "dtDJoined"
        Me.dtDJoined.Size = New System.Drawing.Size(121, 20)
        Me.dtDJoined.TabIndex = 4
        '
        'cmbGender
        '
        Me.cmbGender.FormattingEnabled = True
        Me.cmbGender.Location = New System.Drawing.Point(105, 128)
        Me.cmbGender.Name = "cmbGender"
        Me.cmbGender.Size = New System.Drawing.Size(121, 21)
        Me.cmbGender.TabIndex = 3
        '
        'dtDOB
        '
        Me.dtDOB.Location = New System.Drawing.Point(105, 93)
        Me.dtDOB.Name = "dtDOB"
        Me.dtDOB.Size = New System.Drawing.Size(121, 20)
        Me.dtDOB.TabIndex = 2
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(105, 54)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(121, 20)
        Me.txtSurname.TabIndex = 1
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(105, 19)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(121, 20)
        Me.txtName.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(424, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Member Number:"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(684, 6)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(76, 30)
        Me.btnSearch.TabIndex = 2
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtMemberNum
        '
        Me.txtMemberNum.Location = New System.Drawing.Point(523, 12)
        Me.txtMemberNum.Name = "txtMemberNum"
        Me.txtMemberNum.Size = New System.Drawing.Size(134, 20)
        Me.txtMemberNum.TabIndex = 1
        '
        'lstMembers
        '
        Me.lstMembers.FormattingEnabled = True
        Me.lstMembers.HorizontalExtent = 700
        Me.lstMembers.HorizontalScrollbar = True
        Me.lstMembers.Location = New System.Drawing.Point(3, 6)
        Me.lstMembers.Name = "lstMembers"
        Me.lstMembers.Size = New System.Drawing.Size(409, 316)
        Me.lstMembers.TabIndex = 0
        '
        'tbRaceMan
        '
        Me.tbRaceMan.Controls.Add(Me.lstAthletes)
        Me.tbRaceMan.Controls.Add(Me.GroupBox3)
        Me.tbRaceMan.Location = New System.Drawing.Point(4, 22)
        Me.tbRaceMan.Name = "tbRaceMan"
        Me.tbRaceMan.Padding = New System.Windows.Forms.Padding(3)
        Me.tbRaceMan.Size = New System.Drawing.Size(766, 323)
        Me.tbRaceMan.TabIndex = 1
        Me.tbRaceMan.Text = "Race Management"
        Me.tbRaceMan.UseVisualStyleBackColor = True
        '
        'lstAthletes
        '
        Me.lstAthletes.FormattingEnabled = True
        Me.lstAthletes.HorizontalExtent = 500
        Me.lstAthletes.HorizontalScrollbar = True
        Me.lstAthletes.Location = New System.Drawing.Point(0, 8)
        Me.lstAthletes.Name = "lstAthletes"
        Me.lstAthletes.Size = New System.Drawing.Size(420, 303)
        Me.lstAthletes.TabIndex = 2
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnSaveAthlete)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.txtTimeCompleted)
        Me.GroupBox3.Controls.Add(Me.cmbAthlets)
        Me.GroupBox3.Controls.Add(Me.txtPosition)
        Me.GroupBox3.Controls.Add(Me.cmbRaces)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Location = New System.Drawing.Point(426, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(337, 308)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Provide the following information:"
        '
        'btnSaveAthlete
        '
        Me.btnSaveAthlete.Location = New System.Drawing.Point(210, 251)
        Me.btnSaveAthlete.Name = "btnSaveAthlete"
        Me.btnSaveAthlete.Size = New System.Drawing.Size(121, 51)
        Me.btnSaveAthlete.TabIndex = 9
        Me.btnSaveAthlete.Text = "Save Athlete"
        Me.btnSaveAthlete.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 39)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(76, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Select Athlete:"
        '
        'txtTimeCompleted
        '
        Me.txtTimeCompleted.Location = New System.Drawing.Point(111, 170)
        Me.txtTimeCompleted.Name = "txtTimeCompleted"
        Me.txtTimeCompleted.Size = New System.Drawing.Size(220, 20)
        Me.txtTimeCompleted.TabIndex = 8
        '
        'cmbAthlets
        '
        Me.cmbAthlets.FormattingEnabled = True
        Me.cmbAthlets.Location = New System.Drawing.Point(111, 36)
        Me.cmbAthlets.Name = "cmbAthlets"
        Me.cmbAthlets.Size = New System.Drawing.Size(220, 21)
        Me.cmbAthlets.TabIndex = 0
        '
        'txtPosition
        '
        Me.txtPosition.Location = New System.Drawing.Point(111, 131)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(220, 20)
        Me.txtPosition.TabIndex = 7
        '
        'cmbRaces
        '
        Me.cmbRaces.FormattingEnabled = True
        Me.cmbRaces.Location = New System.Drawing.Point(111, 84)
        Me.cmbRaces.Name = "cmbRaces"
        Me.cmbRaces.Size = New System.Drawing.Size(220, 21)
        Me.cmbRaces.TabIndex = 3
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 173)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 13)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Time Completed:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 87)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(99, 13)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Race Competed In:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(6, 134)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(72, 13)
        Me.Label17.TabIndex = 5
        Me.Label17.Text = "Position Held:"
        '
        'frmRunningClub
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(798, 373)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frmRunningClub"
        Me.Text = "Gauteng Far West Running Club"
        Me.TabControl1.ResumeLayout(False)
        Me.tbEventMan.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tbMemMan.ResumeLayout(False)
        Me.tbMemMan.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.tbRaceMan.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tbMemMan As TabPage
    Friend WithEvents tbRaceMan As TabPage
    Friend WithEvents tbEventMan As TabPage
    Friend WithEvents btnDelEvent As Button
    Friend WithEvents btnUpdateEvent As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents dtEventDate As DateTimePicker
    Friend WithEvents txtDistance As TextBox
    Friend WithEvents txtRegFee As TextBox
    Friend WithEvents txtLocation As TextBox
    Friend WithEvents txtTitle As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents lstEvents As ListBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnDelMemb As Button
    Friend WithEvents btnUpdateMemb As Button
    Friend WithEvents btnSaveMemb As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents cmbCompeted As ComboBox
    Friend WithEvents txtFinishTime As TextBox
    Friend WithEvents txtOwing As TextBox
    Friend WithEvents dtDJoined As DateTimePicker
    Friend WithEvents cmbGender As ComboBox
    Friend WithEvents dtDOB As DateTimePicker
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtMemberNum As TextBox
    Friend WithEvents lstMembers As ListBox
    Friend WithEvents lstAthletes As ListBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cmbAthlets As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents cmbRaces As ComboBox
    Friend WithEvents txtTimeCompleted As TextBox
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents btnSaveAthlete As Button
    Friend WithEvents GroupBox3 As GroupBox
End Class
