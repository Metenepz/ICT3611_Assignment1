﻿Imports System.IO
Public Class frmRunningClub

    Dim memb As Member = New Member
    Dim eventMan As EventManagement
    Dim membList() As Member
    Dim reader As StreamReader
    Dim writer As StreamWriter
    Private Sub frmRunningClub_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Clearing listBoxes and ComboBoxes
        lstAthletes.Items.Clear()
        lstEvents.Items.Clear()
        lstMembers.Items.Clear()
        cmbGender.Items.Clear()
        cmbCompeted.Items.Clear()
        cmbAthlets.Items.Clear()
        cmbRaces.Items.Clear()
        'Populating ListBoxes and Comboxes
        cmbGender.Items.Add("Female")
        cmbGender.Items.Add("Male")
        Dim name, sname, enumb As String
        Dim pos As Integer
        'Adding headings to the members listbox
        lstMembers.Items.Add("Member#" + vbTab + vbTab + "Name and Surname" + vbTab + "Gender" + vbTab + "Competed In" + vbTab + "Finish Time" +
                             vbTab + "Join Date" + vbTab + "Date of Birth" + vbTab + "Outstanding Amount")
        lstMembers.Items.Add("=======" + vbTab + vbTab + "=============" + vbTab + "======" + vbTab + "===========" + vbTab + "==========" +
                             vbTab + "=========" + vbTab + "=============" + vbTab + "==================")
        'Opening the members files
        reader = New StreamReader("Members.txt")
        While Not reader.EndOfStream
            Dim line As String = reader.ReadLine.Replace(",", vbTab)
            lstMembers.Items.Add(line)
            pos = line.IndexOf(vbTab)
            enumb = line.Substring(0, pos)
            line = line.Remove(0, pos + 1)
            pos = line.IndexOf(vbTab)
            name = line.Substring(0, pos)
            line = line.Remove(0, pos + 1)
            pos = line.IndexOf(vbTab)
            sname = line.Substring(0, pos)
            line = line.Remove(0, pos + 1)
            cmbAthlets.Items.Add(enumb + "-" + name + " " + sname)
        End While
        reader.Close() 'Closing the members files

        'Adding headings to the Events listbox
        lstEvents.Items.Add("Event Title" + vbTab + "Event Date" + vbTab + "Registration Fee(R)" + vbTab + "Location" + vbTab + "Distance in KM")

        lstEvents.Items.Add("========" + vbTab + "=========" + vbTab + "===============" + vbTab + "=======" + vbTab + "============")
        reader = New StreamReader("Events.txt") 'Opening the Events file
        While Not reader.EndOfStream
            Dim line As String = reader.ReadLine.Replace(",", vbTab)
            lstEvents.Items.Add(line)
            cmbCompeted.Items.Add(line.Substring(0, line.IndexOf(vbTab)))
            cmbRaces.Items.Add(line.Substring(0, line.IndexOf(vbTab)))
        End While
        reader.Close() 'Closing the event file

        'Adding headings to the Races listbox
        lstAthletes.Items.Add("Athlete Infor" + vbTab + vbTab + vbTab + "Race Competed In" + vbTab + "Position Held" + vbTab + "Time Finished")
        lstAthletes.Items.Add("===============================" + vbTab + "=============" + vbTab + "=============" + vbTab + "=============")
        reader = New StreamReader("Race Results.txt") 'Opening the races file
        While Not reader.EndOfStream
            Dim line As String = reader.ReadLine.Replace(",", vbTab)
            lstAthletes.Items.Add(line)
        End While
        reader.Close() 'Closing the races files
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim line As String
        Dim names, search As String
        Dim isExist As Boolean = False
        'Checking if all required fields are populated with values
        If txtTitle.Text = "" Or txtDistance.Text = "" Or txtLocation.Text = "" Or txtRegFee.Text = "" Then
            MessageBox.Show("One or more fields is/are empty. Please rectify", "Empty fields", MessageBoxButtons.OKCancel,
                            MessageBoxIcon.Error)
        Else
            Try 'Try Catch for catching the exception that can be thrown by the streamReader class

                line = txtTitle.Text + vbTab + Format(dtEventDate.Value, "yyyy-MM-dd") + vbTab + txtRegFee.Text + vbTab + txtLocation.Text + vbTab + txtDistance.Text

                eventMan = New EventManagement(txtTitle.Text, txtLocation.Text, Format(dtEventDate.Value, "yyyy-MM-dd"), CDbl(txtRegFee.Text), txtDistance.Text)
                reader = New StreamReader("Events.txt") 'Creating a new event file
                While Not reader.EndOfStream 'Read a line while the not at end of it
                    names = reader.ReadLine()
                    search = names.Trim().Substring(0, names.IndexOf(","))
                    If search.Equals(txtTitle.Text) Then 'Checking if the event name is not repeating in the file
                        isExist = True
                    End If
                End While
                reader.Close() 'Closing the events file
                writer = New StreamWriter(New FileStream("Events.txt", FileMode.Append))
                If isExist = True Then 'If an event with the same name as the one entered already exists in the file then
                    'an appropriate message should be displayed
                    MessageBox.Show("Event with the same title as the one provided already exists in our system. Please try again",
                                    "Event Naming Conflict", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    writer.WriteLine(line.Replace(vbTab, ",")) 'Replacing the tabs in a line with commas 

                End If
                writer.Close()
                frmRunningClub_Load(sender, e) 'Calling the onLoad event of the form
            Catch ex As InvalidCastException
                MessageBox.Show(ex.Message, "Exception caught", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End Try
        End If
    End Sub
    Public Sub calcCheckDigit(ByRef obj As Member) 'Procedure that receives the a member object as reference parameter to create a member number
        Dim rand As Random = New Random
        Dim line As String = Format(Today(), "yy").ToString() + Format(obj.Birthdate, "yyyyMMdd").ToString() + rand.Next(0, 999).ToString()
        obj.M_Number = line

        Dim sum As Integer = 0 'Declaring and assigning the value 0 to the sum variable
        Dim j As Integer = 1
        For i As Integer = 0 To 12
            sum += CInt(line.Substring(i, j)) 'Accumulating the sum of individual digits in the member member
        Next
        If sum Mod 10 = 0 Then 'Check if the sum accumulated above modulus 10 is equal to 0
            obj.M_Number = obj.M_Number + "0" 'If the above condition is true, the append 0 to the member number 
        Else
            obj.M_Number = obj.M_Number + (10 - (sum Mod 10)).ToString() 'Else append the difference between 10 and the remainder of sum modulus 10 
        End If
    End Sub

    Private Sub btnSaveMemb_Click(sender As Object, e As EventArgs) Handles btnSaveMemb.Click
        Dim line As String
        If txtName.Text = "" Or txtSurname.Text = "" Or cmbGender.Text = "" Or txtOwing.Text = "" Or txtFinishTime.Text = "" Then
            MessageBox.Show("One or more fields is/are empty. Please rectify", "Empty fields", MessageBoxButtons.OKCancel,
                            MessageBoxIcon.Error)
        Else

            Try
                memb = New Member(txtName.Text, txtSurname.Text, cmbGender.Text, cmbCompeted.Text, txtFinishTime.Text, dtDJoined.Value,
                              dtDOB.Value, CDbl(txtOwing.Text))
                calcCheckDigit(memb)
                line = memb.M_Number + "," + memb.Fname + "," + memb.Lname + "," + memb.Gen + "," + memb.R_Completed + "," + memb.FTime + "," + memb.JDate + "," + memb.Birthdate + "," + memb.Owing.ToString()
                writer = New StreamWriter(New FileStream("Members.txt", FileMode.Append))
                writer.WriteLine(line)
                writer.Close()
                frmRunningClub_Load(sender, e)
            Catch ex As IOException
                MessageBox.Show("Error: Data not written to the file", "Input Output Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Public Function calcItems(ByVal file As String) As Integer
        Dim count As Integer = 0

        reader = New StreamReader(file)
        While reader.EndOfStream
            count += 1
        End While
        reader.Close()
        Return count
    End Function

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim line, search As String
        Dim pos As Integer
        Dim found As Boolean
        Dim inputed As String = txtMemberNum.Text
        For i As Integer = 2 To lstMembers.Items.Count - 1
            line = lstMembers.Items.Item(i)
            search = line.Substring(0, line.IndexOf(vbTab)).Trim()
            If search.Equals(inputed) Then
                found = True
                pos = i
            End If
        Next
        If checkDigit(inputed) Then
            If found Then
                lstMembers.SelectedIndex = pos
            Else
                MessageBox.Show("Member not found")
            End If
        Else
            MessageBox.Show("The member number provided is not valid", "Invalid Member Number", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

    End Sub
    Public Function checkDigit(ByVal membNum As String) As Boolean 'Function for checking if the member number provided is valid or not
        Dim valid As Boolean = False 'Assigning the value false to the boolean variable valid
        Dim sum As Integer = 0
        Dim j As Integer = 1
        For i As Integer = 0 To 13
            sum += CInt(membNum.Substring(i, j))
        Next
        If sum Mod 10 = 0 Then 'Member number is valid if the sum of individual digits in the member number provided modulus 10 equals 0, if not then it is invalid
            valid = True
        End If
        Return valid 'Returning the results
    End Function

    Private Sub lstEvents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstEvents.SelectedIndexChanged
        If lstEvents.SelectedIndex > 1 Then
            Dim line As String = lstEvents.SelectedItem

            Dim pos As Integer = line.IndexOf(vbTab)

            txtTitle.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            dtEventDate.Value = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            txtRegFee.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            txtLocation.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            txtDistance.Text = line
        End If
    End Sub

    Private Sub btnDelMemb_Click(sender As Object, e As EventArgs) Handles btnDelMemb.Click
        writer = New StreamWriter("Members.txt")
        writer.Close()
        If lstMembers.SelectedIndex = -1 Then
            MessageBox.Show("Error occured: First select the member to delete", "Select Member", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            lstMembers.Items.RemoveAt(lstMembers.SelectedIndex)
            writer = New StreamWriter(New FileStream("Members.txt", FileMode.Append))
            For i As Integer = 2 To lstMembers.Items.Count - 1
                writer.WriteLine(lstMembers.Items.Item(i).ToString().Replace(vbTab, ","))
            Next
            writer.Close()
            frmRunningClub_Load(sender, e)
        End If
    End Sub

    Private Sub lstMembers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstMembers.SelectedIndexChanged
        If lstMembers.SelectedIndex > 1 Then
            Dim line As String = lstMembers.SelectedItem

            Dim pos As Integer = line.IndexOf(vbTab)
            Dim eNumber As String
            eNumber = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            txtName.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            txtSurname.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            cmbGender.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            cmbCompeted.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            txtFinishTime.Text = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            dtDJoined.Value = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            pos = line.IndexOf(vbTab)
            dtDOB.Value = line.Substring(0, pos).Trim()
            line = line.Remove(0, pos + 1)

            txtOwing.Text = line
        End If
    End Sub

    Private Sub btnUpdateMemb_Click(sender As Object, e As EventArgs) Handles btnUpdateMemb.Click
        Dim eNumb As String
        Dim indx As Integer
        If lstMembers.SelectedIndex < 1 Then
            MessageBox.Show("Error occured: First select the member to update", "Select Member", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            writer = New StreamWriter("Members.txt")
            writer.Close()
            indx = lstMembers.SelectedIndex
            eNumb = lstMembers.SelectedItem.ToString.Substring(0, lstMembers.SelectedItem.ToString.IndexOf(vbTab))
            lstMembers.Items.RemoveAt(lstMembers.SelectedIndex)
            memb = New Member(txtName.Text, txtSurname.Text, cmbGender.Text, cmbCompeted.Text, txtFinishTime.Text, dtDJoined.Value,
                              dtDOB.Value, CDbl(txtOwing.Text))
            lstMembers.Items.Insert(indx, eNumb + vbTab + memb.Fname + vbTab + memb.Lname + vbTab + memb.Gen + vbTab + memb.R_Completed + vbTab + memb.FTime + vbTab + memb.JDate + vbTab + memb.Birthdate + vbTab + memb.Owing.ToString)
            writer = New StreamWriter(New FileStream("Members.txt", FileMode.Append))
            For i As Integer = 2 To lstMembers.Items.Count - 1
                writer.WriteLine(lstMembers.Items.Item(i).ToString().Replace(vbTab, ","))
            Next
            writer.Close()
        End If
        frmRunningClub_Load(sender, e)
    End Sub

    Private Sub btnSaveAthlete_Click(sender As Object, e As EventArgs) Handles btnSaveAthlete.Click
        If cmbAthlets.Text = "" Or cmbRaces.Text = "" Or txtPosition.Text = "" Or txtTimeCompleted.Text = "" Then
            MessageBox.Show("One or more fields is/are empty. Please rectify", "Empty fields", MessageBoxButtons.OKCancel,
                            MessageBoxIcon.Error)
        Else
            Try
                writer = New StreamWriter(New FileStream("Race Results.txt", FileMode.Append))
                Dim line As String
                line = cmbAthlets.Text + vbTab + cmbRaces.Text + vbTab + txtPosition.Text + vbTab + txtTimeCompleted.Text
                lstAthletes.Items.Add(line)
                line = line.Replace(vbTab, ",")
                writer.WriteLine(line)
                writer.Close()
            Catch ex As IOException
                MessageBox.Show("Error: Data not written to the file", "Input Output Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub btnUpdateEvent_Click(sender As Object, e As EventArgs) Handles btnUpdateEvent.Click
        Dim indx As Integer
        If lstEvents.SelectedIndex < 1 Then
            MessageBox.Show("Error occured: First select the event to update", "Select Event", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            writer = New StreamWriter("Events.txt")
            writer.Close()
            indx = lstEvents.SelectedIndex
            lstEvents.Items.RemoveAt(lstEvents.SelectedIndex)
            eventMan = New EventManagement(txtTitle.Text, txtLocation.Text, dtEventDate.Value, CDbl(txtRegFee.Text), CDbl(txtDistance.Text))
            lstEvents.Items.Insert(indx, eventMan.EveTitle + vbTab + eventMan.EveDate + vbTab + eventMan.Reg_Fee.ToString + vbTab + eventMan.EveLocation + vbTab + eventMan.EveDistance.ToString)
            writer = New StreamWriter(New FileStream("Events.txt", FileMode.Append))
            For i As Integer = 2 To lstEvents.Items.Count - 1
                writer.WriteLine(lstEvents.Items.Item(i).ToString().Replace(vbTab, ","))
            Next
            writer.Close()
        End If
        frmRunningClub_Load(sender, e)
    End Sub

    Private Sub btnDelEvent_Click(sender As Object, e As EventArgs) Handles btnDelEvent.Click
        writer = New StreamWriter("Events.txt")
        writer.Close()
        Dim isExist As Boolean = False

        If lstEvents.SelectedIndex = -1 Then
            MessageBox.Show("Error occured: First select the event to delete", "Select Event", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim Ename As String
            Dim search As String = lstEvents.SelectedItem
            Ename = search.Substring(0, search.IndexOf(vbTab))
            reader = New StreamReader("Race Results.txt") 'Opening the races file
            While Not reader.EndOfStream
                Dim line As String = reader.ReadLine.Replace(",", vbTab)
                If line.Contains(Ename) Then
                    isExist = True
                End If
            End While
            reader.Close() 'Closing the races files
            If isExist Then
                MessageBox.Show("The cannot be deleted, because it already have members who participated in it", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                lstEvents.Items.RemoveAt(lstEvents.SelectedIndex)
                Try
                    writer = New StreamWriter(New FileStream("Events.txt", FileMode.Append))
                    For i As Integer = 2 To lstEvents.Items.Count - 1
                        writer.WriteLine(lstEvents.Items.Item(i).ToString().Replace(vbTab, ","))
                    Next
                Catch ex As IOException
                    MessageBox.Show("Error: Data not written to the file", "Input Output Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    writer.Close()
                    frmRunningClub_Load(sender, e)
                End Try
            End If
        End If
    End Sub
End Class


