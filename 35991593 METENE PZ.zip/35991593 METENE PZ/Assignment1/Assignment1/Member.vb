﻿Public Class Member
    Private membNumber, name, surname, gender, raceCompeted, finishTime As String
    Private joinDate, dob As Date
    Private outstandingFee As Double

    Public Sub New()
        Me.membNumber = ""
        Me.name = ""
        Me.surname = ""
        Me.gender = ""
        Me.raceCompeted = ""
        Me.finishTime = ""
        Me.joinDate = Format(Today(), "yyyy-MM-dd")
        Me.dob = Format(Date.Parse("1900-05-25"), "yyyy-MM-dd")
        Me.outstandingFee = 0.0
    End Sub

    Public Sub New(name As String, surname As String, gen As String,
                   completed As String, finish As String, jdate As Date, birthdate As Date, owing As Double)
        Me.membNumber = ""
        Me.name = name
        Me.surname = surname
        Me.gender = gen
        Me.raceCompeted = completed
        Me.finishTime = finish
        Me.joinDate = Format(Date.Parse(jdate), "yyyy-MM-dd")
        Me.dob = Format(Date.Parse(birthdate), "yyyy-MM-dd")
        Me.outstandingFee = owing
    End Sub

    Public Property M_Number As String
        Get
            Return membNumber
        End Get
        Set(value As String)
            membNumber = value
        End Set
    End Property

    Public Property Fname As String
        Get
            Return name
        End Get
        Set(value As String)
            name = value
        End Set
    End Property

    Public Property Lname As String
        Get
            Return surname
        End Get
        Set(value As String)
            surname = value
        End Set
    End Property

    Public Property Gen As String
        Get
            Return gender
        End Get
        Set(value As String)
            gender = value
        End Set
    End Property

    Public Property R_Completed As String
        Get
            Return raceCompeted
        End Get
        Set(value As String)
            raceCompeted = value
        End Set
    End Property

    Public Property FTime As String
        Get
            Return finishTime
        End Get
        Set(value As String)
            finishTime = value
        End Set
    End Property

    Public Property JDate As Date
        Get
            Return joinDate
        End Get
        Set(value As Date)
            joinDate = value
        End Set
    End Property

    Public Property Birthdate As Date
        Get
            Return dob
        End Get
        Set(value As Date)
            dob = value
        End Set
    End Property

    Public Property Owing As Double
        Get
            Return outstandingFee
        End Get
        Set(value As Double)
            outstandingFee = value
        End Set
    End Property


End Class
