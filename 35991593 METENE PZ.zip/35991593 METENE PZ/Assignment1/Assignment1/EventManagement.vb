﻿Public Class EventManagement
    Private title, location As String
    Private eventDate As Date
    Private regFee, distance As Double

    Public Sub New()
        Me.title = ""
        Me.location = ""
        Me.eventDate = Format(Today(), "yyyy-MM-dd")
        Me.regFee = 0.0
        Me.distance = 0.0
    End Sub

    Public Sub New(title As String, location As String, eventDate As Date, regFee As Double, distance As Double)
        Me.title = title
        Me.location = location
        Me.eventDate = Format(eventDate, "yyyy-MM-dd")
        Me.regFee = regFee
        Me.distance = distance
    End Sub

    Public Property EveTitle As String
        Get
            Return title
        End Get
        Set(value As String)
            title = value
        End Set
    End Property

    Public Property EveLocation As String
        Get
            Return location
        End Get
        Set(value As String)
            location = value
        End Set
    End Property

    Public Property EveDate As Date
        Get
            Return eventDate
        End Get
        Set(value As Date)
            eventDate = value
        End Set
    End Property

    Public Property Reg_Fee As Double
        Get
            Return regFee
        End Get
        Set(value As Double)
            regFee = value
        End Set
    End Property

    Public Property EveDistance As Double
        Get
            Return distance
        End Get
        Set(value As Double)
            distance = value
        End Set
    End Property
End Class
